import type { NativePath, PortablePath } from '@yarnpkg/fslib';
export declare function readPackageScope(checkPath: NativePath): false | {
    data: any;
    path: NativePath;
};
export declare function readPackage(requestPath: NativePath): any;
export declare function ERR_REQUIRE_ESM(filename: string, parentPath?: string | null): Error & {
    code: string;
};
export declare function reportRequiredFilesToWatchMode(paths: Array<PortablePath>): void;
