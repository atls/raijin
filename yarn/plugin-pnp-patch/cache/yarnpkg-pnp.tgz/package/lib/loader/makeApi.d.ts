import { FakeFS, NativePath, PortablePath } from '@yarnpkg/fslib';
import { PnpApi, RuntimeState } from '../types';
export type MakeApiOptions = {
    allowDebug?: boolean;
    compatibilityMode?: boolean;
    fakeFs: FakeFS<PortablePath>;
    pnpapiResolution: NativePath;
};
export declare function makeApi(runtimeState: RuntimeState, opts: MakeApiOptions): PnpApi;
