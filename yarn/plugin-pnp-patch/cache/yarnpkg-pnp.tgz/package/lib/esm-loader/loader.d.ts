import { load as loadHook } from './hooks/load';
import { resolve as resolveHook } from './hooks/resolve';
import './fspatch';
export declare const resolve: typeof resolveHook;
export declare const load: typeof loadHook;
