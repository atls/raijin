export declare const WATCH_MODE_MESSAGE_USES_ARRAYS: boolean;
export declare const HAS_LAZY_LOADED_TRANSLATORS: boolean;
export declare const HAS_LOADERS_AFFECTING_LOADERS: boolean;
export declare const ALLOWS_EXTENSIONLESS_FILES: boolean;
export declare const SUPPORTS_IMPORT_ATTRIBUTES: boolean;
export declare const SUPPORTS_IMPORT_ATTRIBUTES_ONLY: boolean;
export declare const HAS_BROKEN_FSTAT_FOR_ZIP_FDS: boolean;
